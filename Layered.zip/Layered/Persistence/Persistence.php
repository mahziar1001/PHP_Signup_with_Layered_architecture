<?php
if($_SESSION["name"] && $_SESSION["password"] && $_SESSION["email"])
{
    $name = $_SESSION["name"];
    $email = $_SESSION["email"];
    $password = $_SESSION["password"];
    $con = mysqli_connect("localhost", "root", "", "db");
    $query = "INSERT INTO users VALUES($name, $email, $password)";
    $result = mysqli_query($con, $query);
}
?>