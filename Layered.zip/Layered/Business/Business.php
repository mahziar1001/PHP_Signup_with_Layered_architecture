<?php
if(isset($_POST["OK"]))
{
    $_SESSION["name"] = strip_tags($_POST["name"]);
    $_SESSION["email"] = strip_tags($_POST["email"]);
    $_SESSION["password"] = strip_tags($_POST["password"]);
    header("location:/projects/Layered/Persistence/Persistence.php");
}
?>