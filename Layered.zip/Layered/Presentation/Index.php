<html>
<head>
<title>Layered Architecture(Sign Up)</title>
</head>
<body>
    <h1>Sign Up</h1>
    <center>
    <form action="/projects/Layered/Business/Business.php" method="post">
        <input type="text" name="name" placeholder="name">
        <input type="email" name="email" placeholder="email">
        <input type="password" name="password" placeholder="password">
        <input type="submit" name="OK" value="OK">
    </form>
    </center>
</body>
</html>